# team-success
I am creating multiple online stores; therefore, I have multiple email accounts. I am a sole-proprietor entrepreneur.
